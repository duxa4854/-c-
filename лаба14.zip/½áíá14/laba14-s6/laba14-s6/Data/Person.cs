﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba14_s6.Data
{
    public class Person
    {
    public int Age { get; set; }
    public string Name { get; set; }
    }
    
    }

